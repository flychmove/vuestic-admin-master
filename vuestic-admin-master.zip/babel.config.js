module.exports = {
  presets: [
    '@vue/cli-plugin-babel/preset',
  ],
  // old version
  // presets: [[
  //   '@vue/app',
  //   {
  //     useBuiltIns: 'entry',
  //   },
  // ]],
}
