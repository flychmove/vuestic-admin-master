type ColorThemes = {
  [key: string]: string;
};
