<template>
  <router-view class="page-404" />
</template>
