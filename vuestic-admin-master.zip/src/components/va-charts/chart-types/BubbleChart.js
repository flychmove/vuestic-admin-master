import { Bubble } from 'vue-chartjs'
import chartMixin from './chartMixin'

export default {
  mixins: [Bubble, chartMixin],
}
