export default {
  color: 'primary'
}